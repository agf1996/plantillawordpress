<?php get_header(); ?>


<?php get_sidebar(); ?>

<link rel="stylesheet" type="text/css" href="<?php bloginfo('stylesheet_url'); ?>"  />

<?php if (have_posts() ) :
    while ( have_posts() ) : the_post(); ?>
    <h1><?php the_title();?></h1>
   <p id="contingut"> <?php the_content();?> </p>
    <?php endwhile;
else : 
    _e("No Hi Ha res", "text-domain");
    endif ?>

<nav class="sidebar">
    </nav>
    <?php get_sidebar('ejemplo'); ?>

<?php get_footer(); ?>