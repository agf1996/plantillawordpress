<?php 

function registrar_menu(){
    //Per a definir la ubicació del arxiu
    register_nav_menus(array(
        'header-menu' => 'Header Menu',
    ));
}
function elMeuTema_setup() {
  // Preparant el tema per a i18n
  load_theme_textdomain( "elMeuTema", bloginfo('template_url')."/languages");

  // Suport a thumbnails
  add_theme_support( 'post-thumbnails' );

  // Afig enllaços als comentaris i a l'RSS
  add_theme_support( 'automatic-feed-links' );

  // Deixa que Wordpress gestione el títol
  add_theme_support( 'title-tag' );

  // Activa el suport per a un logotipus personalitzat
  add_theme_support( 'custom-logo', array(
      'height' => 240,
      'width' => 240,
      'flex-height' => true,
  ) );
}



function registrar_sidebar(){
    register_sidebar(array(
     'name' => 'Sidebar de ejemplo',
     'id' => 'sidebar-ejemplo',
     'description' => 'Descripción de ejemplo',
     'class' => 'sidebar',
     'before_widget' => '<aside id="%1$s" class="widget %2$s">',
     'after_widget' => '</aside>',
     'before_title' => '<h2 class="widget-title">',
     'after_title' => '</h2>',
    ));
  }
  add_action( 'widgets_init', 'registrar_sidebar');

 
  ?>


<link rel="stylesheet" type="text/css" href="<?php bloginfo('stylesheet_url'); ?>"  />