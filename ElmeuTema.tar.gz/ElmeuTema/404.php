<?php get_header(); ?>

<section class="container">
<br/>
<div class="text-center alert alert-danger row" role="alert">
<h2 class="col-md-12">Ni esta ni se le espera</h2>
</div>
</section>

<?php get_footer(); ?>
