</div>  
<!-- Footer -->
<footer class="bg-dark">
  
      <div class="container">
        <p class="m-0 text-white"><?php bloginfo('name');?>.  <?php echo date('Y');?></p>
      </div>
<!-- /.container -->
</footer>

<?php wp_footer();?>
</body>
</html>

